//Realizado por Jose de Bello, ALicia Jaen, Sherlyn Caballero, Mateo Henao, Ivan Anselmi 1IL22
public class NumeroDesa {
    private int resul;
    private String preg;
    
    public int getResul() {
        return resul;
    }
    public void setResul(int resul) {
        this.resul = resul;
    }
    public String getPreg() {
        return preg;
    }
    public void setPreg(String preg) {
        this.preg = preg;
    }

    
}
